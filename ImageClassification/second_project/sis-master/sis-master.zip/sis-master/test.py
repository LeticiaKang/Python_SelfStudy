import numpy as np
from PIL import Image
from feature_extractor import FeatureExtractor
from datetime import datetime
from flask import Flask, request, render_template
from pathlib import Path

print(np.load("C:\Self_Study\PythonStudy\ImageClassification\second_project\sis-master\sis-master\static\feature\뷔 (4).npy"))